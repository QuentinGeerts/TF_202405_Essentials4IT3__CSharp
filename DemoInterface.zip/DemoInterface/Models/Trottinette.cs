﻿using DemoInterface.Interfaces;

namespace DemoInterface.Models;

internal class Trottinette : IMoyenNonMotorise
{
}
