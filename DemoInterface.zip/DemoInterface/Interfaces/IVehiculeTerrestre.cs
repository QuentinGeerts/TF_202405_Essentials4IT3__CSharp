﻿namespace DemoInterface.Interfaces;

internal interface IVehiculeTerrestre : IVehicule
{
    void Rouler();
}
