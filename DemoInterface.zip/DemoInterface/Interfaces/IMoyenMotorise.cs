﻿namespace DemoInterface.Interfaces;

internal interface IMoyenMotorise : IMoyenLocomotion
{
}
