﻿namespace DemoInterface.Interfaces;

internal interface IMoyenNonMotorise : IMoyenLocomotion
{
}
