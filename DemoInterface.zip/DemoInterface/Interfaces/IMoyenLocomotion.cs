﻿namespace DemoInterface.Interfaces;

internal interface IMoyenLocomotion
{
}
