﻿namespace DemoInterface.Interfaces;

internal interface IVehiculeMaritime : IVehicule
{
    void Voguer();
}
