﻿namespace DemoInterface.Enums;

internal enum TypeCarburant
{
    Diesel,
    Essence,
    Electrique
}
